package com.example.bestmovie

data class MovieItem(
    val title: String,
    val author: String,
    val posterPath: String
)

package com.example.bestmovie

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StyleSpan


class BestMovieRecyclerViewAdapter(private var movieList: List<MovieItem>) : RecyclerView.Adapter<BestMovieRecyclerViewAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.book_title)
        val authorTextView: TextView = itemView.findViewById(R.id.book_author)
        val posterImageView: ImageView = itemView.findViewById(R.id.thumbnailImageView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.fragment_best_movie, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val movieItem = movieList[position]
        holder.titleTextView.text = movieItem.title
        holder.authorTextView.text = movieItem.author

        val spannableTitle = SpannableString(movieItem.title)
        spannableTitle.setSpan(StyleSpan(Typeface.BOLD), 0, spannableTitle.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        holder.titleTextView.text = spannableTitle

        val posterUrl = "https://image.tmdb.org/t/p/w500${movieItem.posterPath}"

        Glide.with(holder.itemView.context)
            .load(posterUrl)
            .apply(RequestOptions.placeholderOf(R.drawable.placeholder))
            .apply(RequestOptions.errorOf(R.drawable.error))
            .into(holder.posterImageView)
    }

    override fun getItemCount(): Int {
        return movieList.size
    }

    fun updateData(newData: List<MovieItem>) {
        movieList = newData
        notifyDataSetChanged()
    }
}

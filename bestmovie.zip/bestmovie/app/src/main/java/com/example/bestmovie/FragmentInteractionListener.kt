package com.example.bestmovie

interface FragmentInteractionListener {

    fun onItemSelected(itemId: Int)

}

package com.example.bestmovie

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import android.content.res.Configuration

class BestMovieFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var adapter: BestMovieRecyclerViewAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val orientation = resources.configuration.orientation
        val layoutId = if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            R.layout.fragment_best_movie_list
        } else {
            R.layout.fragment_best_movie_list_land
        }

        val view = inflater.inflate(layoutId, container, false)


        recyclerView = view.findViewById(R.id.list)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        adapter = BestMovieRecyclerViewAdapter(emptyList())
        recyclerView.adapter = adapter

        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout)

        swipeRefreshLayout.setOnRefreshListener {
            fetchNowPlayingMovies()
        }

        fetchNowPlayingMovies()

        return view
    }
    private fun fetchNowPlayingMovies() {
        val apiKey = "a07e22bc18f5cb106bfe4cc1f83ad8ed"
        val url = "https://api.themoviedb.org/3/movie/now_playing?api_key=$apiKey"

        val client = OkHttpClient()

        val request = Request.Builder()
            .url(url)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                swipeRefreshLayout.isRefreshing = false
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { json ->
                    val movieList = parseMovieData(json)
                    activity?.runOnUiThread {
                        adapter.updateData(movieList)
                        swipeRefreshLayout.isRefreshing = false
                    }
                }
            }
        })
    }

    private fun parseMovieData(json: String): List<MovieItem> {
        val movieList = mutableListOf<MovieItem>()

        val jsonObject = JSONObject(json)
        val resultsArray = jsonObject.getJSONArray("results")

        for (i in 0 until resultsArray.length()) {
            val movieObject = resultsArray.getJSONObject(i)
            val title = movieObject.getString("title")
            val synopsis = movieObject.getString("overview")
            val posterPath = movieObject.getString("poster_path")

            val posterUrl = "https://image.tmdb.org/t/p/w200$posterPath"

            movieList.add(MovieItem(title, synopsis, posterUrl))
        }

        return movieList
    }
}